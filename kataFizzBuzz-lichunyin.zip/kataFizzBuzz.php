<?php
//Stage 1
print "\r\n============== Stage 1 ==============r\n";
for($i = 1; $i <= 100; $i ++){
    $is_print = false;
    if($i % 3 == 0){
        print 'Fizz';
        $is_print = true;
    }
    if($i % 5 == 0){
        print 'Buzz';
        $is_print = true;
    }
    if($is_print == false){
        print $i;
    }
    print "\r\n";
}

//Stage 2
print "\r\n============== Stage 2 ==============r\n";
for($i = 1; $i <= 100; $i ++){
    $is_print = false;
    if($i % 3 == 0 || $i % 10 == 3 || ($i >= 30 && $i < 40)){
        print 'Fizz';
        $is_print = true;
    }
    if($i % 5 == 0 || $i % 10 == 5 || ($i >= 50 && $i < 60)){
        print 'Buzz';
        $is_print = true;
    }
    if($is_print == false){
        print $i;
    }
    print "\r\n";
}


//Stage 3 
print "\r\n============== Stage 3 ==============r\n";
/**
 * 自己额外做了一个输入任意正整数。输出
 *  - 如果被3整除或者数字中含有3，输出 fizz
 *  - 如果被5整除或者数字中含有5，输出 buzz
 *  - 否则输出数字
 *  - fizz和buzz可以同时输出
 * @param number $i The argument can by any positive integer
 */
function fizzBuzz($number)
{
    for($i = 1; $i <= $number; $i ++){
        
        $digit_relnum   = 1;
        $digit_calnum   = $i;
        while($digit_calnum >= 10){
            $digit_relnum *= 10;
            $digit_calnum /= 10;
        }
        
        $is_print = false;
        if($i % 3 == 0){
            print 'Fizz';
            $is_print = true;
        }else if($i / ($digit_relnum / 10)>= 30 && $i / ($digit_relnum / 10) < 40){ // 30~39、 300~399, 3000~3999, ...
            print 'Fizz';
            $is_print = true;
        }else{ // 13, 130 ~ 139, 1300~1399, ...
            $test_digit = $digit_relnum;
            while($test_digit >= 10){
                $test_num = $i % $test_digit / ($test_digit / 10);
                if($test_num >= 3 && $test_num < 4){
                    print 'Fizz';
                    $is_print = true;
                    break;
                }
                $test_digit /= 10;
            }
        }
        
        if($i % 5 == 0){
            print 'Buzz';
            $is_print = true;
        }else if($i / ($digit_relnum / 10) >= 50 && $i / ($digit_relnum / 10) < 60){ // 50~59、 500~599, 5000~5999, ...
            print 'Buzz';
            $is_print = true;
        }else{ // 15, 150 ~ 159, 1500~1599, ...
            $test_digit = $digit_relnum;
            while($test_digit >= 10){
                $test_num = $i % $test_digit / ($test_digit / 10);
                if($test_num >= 5 && $test_num < 6){
                    print 'Buzz';
                    $is_print = true;
                    break;
                }
                $test_digit /= 10;
            }
        }
        
        if($is_print == false){
            print $i;
        }
        print "\r\n";
    }
}
fizzBuzz(100000);
